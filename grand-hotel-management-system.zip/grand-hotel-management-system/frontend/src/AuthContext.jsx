import {createContext,useContext,useMemo,useState} from 'react';
const AuthContext=createContext(null);
export function AuthProvider({children}) {
 const [user,setUser]=useState(()=>{try{return JSON.parse(localStorage.getItem('grand_hotel_user')||'null')}catch{return null}});
 const login=(data)=>{localStorage.setItem('grand_hotel_token',data.token);localStorage.setItem('grand_hotel_user',JSON.stringify(data.user));setUser(data.user)};
 const logout=()=>{localStorage.removeItem('grand_hotel_token');localStorage.removeItem('grand_hotel_user');setUser(null)};
 const value=useMemo(()=>({user,login,logout}),[user]);
 return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth=()=>useContext(AuthContext);
