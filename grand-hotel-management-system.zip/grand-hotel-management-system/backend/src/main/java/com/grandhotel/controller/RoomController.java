package com.grandhotel.controller;
import com.grandhotel.entity.Room;
import com.grandhotel.service.RoomService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
@RestController @RequestMapping("/api/rooms")
public class RoomController {
 private final RoomService service; public RoomController(RoomService service){this.service=service;}
 @GetMapping public List<Room> all(){return service.all().stream().filter(r->r.getStatus()!=com.grandhotel.entity.RoomStatus.INACTIVE).toList();}
 @GetMapping("/{id}") public Room get(@PathVariable Long id){return service.get(id);}
 @GetMapping("/available") public List<Room> available(@RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate checkIn,@RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate checkOut,@RequestParam(defaultValue="1") int guests){return service.available(checkIn,checkOut,guests);}
}
