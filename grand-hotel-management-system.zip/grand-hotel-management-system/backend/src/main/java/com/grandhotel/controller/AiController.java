package com.grandhotel.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.grandhotel.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import java.util.*;

@RestController @RequestMapping("/api/ai")
public class AiController {
 private final RoomRepository rooms; private final String apiKey; private final String model; private final RestClient client=RestClient.create(); private final ObjectMapper mapper=new ObjectMapper();
 public AiController(RoomRepository rooms,@Value("${app.openai.api-key:}") String apiKey,@Value("${app.openai.model:gpt-4o-mini}") String model){this.rooms=rooms;this.apiKey=apiKey;this.model=model;}
 public record ChatRequest(String message){}
 @PostMapping("/chat") public Map<String,String> chat(@RequestBody ChatRequest request){
  if(request.message()==null||request.message().isBlank()||request.message().length()>2000) return Map.of("reply","Please enter a question of up to 2,000 characters.");
  String roomContext=rooms.findAll().stream().filter(r->r.getStatus()==com.grandhotel.entity.RoomStatus.AVAILABLE).limit(30).map(r->r.getRoomType()+" room "+r.getRoomNumber()+", ₹"+r.getPricePerNight()+"/night, capacity "+r.getCapacity()+", amenities: "+r.getAmenities()).reduce((a,b)->a+"; "+b).orElse("No currently listed rooms.");
  if(apiKey.isBlank()) return Map.of("reply","Hello! I’m the Grand Hotel assistant. I can help with room types, amenities and booking steps. Current listed rooms: "+roomContext+". For AI-generated answers, configure OPENAI_API_KEY on the backend. Date-specific availability is checked by the room search API.");
  try {
   Map<String,Object> body=Map.of("model",model,"messages",List.of(
    Map.of("role","system","content","You are the Grand Hotel customer assistant. Be concise and friendly. Do not claim a booking was made. Do not invent dates, prices, or availability. Listed room context: "+roomContext),
    Map.of("role","user","content",request.message())
   ),"temperature",0.3);
   String response=client.post().uri("https://api.openai.com/v1/chat/completions").header(HttpHeaders.AUTHORIZATION,"Bearer "+apiKey).contentType(MediaType.APPLICATION_JSON).body(body).retrieve().body(String.class);
   JsonNode root=mapper.readTree(response); String answer=root.path("choices").path(0).path("message").path("content").asText();
   return Map.of("reply",answer.isBlank()?"Sorry, I couldn't generate a response. Please try again.":answer);
  } catch(Exception ex){return Map.of("reply","The AI assistant is temporarily unavailable. Please use the room search or contact the hotel directly.");}
 }
}
