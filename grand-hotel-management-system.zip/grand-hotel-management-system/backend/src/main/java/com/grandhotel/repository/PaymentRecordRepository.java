package com.grandhotel.repository;
import com.grandhotel.entity.PaymentRecord; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface PaymentRecordRepository extends JpaRepository<PaymentRecord,Long> {
 List<PaymentRecord> findByBookingCustomerIdOrderByCreatedAtDesc(Long id);
 boolean existsByBookingIdAndStatus(Long bookingId,String status);
}
