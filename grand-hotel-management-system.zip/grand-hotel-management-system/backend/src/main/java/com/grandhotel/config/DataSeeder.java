package com.grandhotel.config;
import com.grandhotel.entity.*;
import com.grandhotel.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;
@Configuration
public class DataSeeder {
 @Bean CommandLineRunner seed(RoomRepository rooms,UserRepository users,PasswordEncoder encoder,
   @Value("${app.seed.admin-email:}") String adminEmail,@Value("${app.seed.admin-password:}") String adminPassword) {
  return args->{
   if(rooms.count()==0){
    add(rooms,"101","STANDARD","2500",2,"Comfortable standard room","Wi-Fi, Air conditioning, TV","https://images.unsplash.com/photo-1611892440504-42a792e24d32");
    add(rooms,"201","DELUXE","4200",2,"Elegant deluxe room with city views","Wi-Fi, Air conditioning, TV, Mini bar","https://images.unsplash.com/photo-1611892440504-42a792e24d32");
    add(rooms,"301","SUITE","7500",4,"Spacious suite for families","Wi-Fi, Living area, Mini bar, Bathtub","https://images.unsplash.com/photo-1578683010236-d716f9a3f461");
    add(rooms,"401","PRESIDENTIAL","15000",4,"Premium presidential suite","Private lounge, Wi-Fi, Dining area, Bathtub","https://images.unsplash.com/photo-1582719478250-c89cae4dc85b");
   }
   if(adminEmail!=null&&!adminEmail.isBlank()&&adminPassword!=null&&!adminPassword.isBlank()&&!users.existsByEmail(adminEmail.toLowerCase())){
    User u=new User();u.setName("Grand Hotel Administrator");u.setEmail(adminEmail.toLowerCase());u.setPassword(encoder.encode(adminPassword));u.setRole(com.grandhotel.entity.Role.ADMIN);users.save(u);
   }
  };
 }
 private void add(RoomRepository repo,String no,String type,String price,int capacity,String desc,String amenities,String image){
  Room r=new Room();r.setRoomNumber(no);r.setRoomType(type);r.setPricePerNight(new BigDecimal(price));r.setCapacity(capacity);r.setDescription(desc);r.setAmenities(amenities);r.setImageUrl(image);r.setStatus(RoomStatus.AVAILABLE);repo.save(r);
 }
}
