package com.grandhotel.controller;
import com.grandhotel.entity.Booking;
import com.grandhotel.service.BookingService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
@RestController @RequestMapping("/api/bookings")
public class BookingController {
 private final BookingService service; public BookingController(BookingService service){this.service=service;}
 public record CreateBooking(@NotNull Long roomId,@NotNull LocalDate checkIn,@NotNull LocalDate checkOut,@Min(1) int guests){}
 @PostMapping public Booking create(Authentication a,@Valid @RequestBody CreateBooking r){return service.create(a.getName(),r.roomId(),r.checkIn(),r.checkOut(),r.guests());}
 @GetMapping("/my") public List<Booking> mine(Authentication a){return service.mine(a.getName());}
 @PostMapping("/{id}/cancel") public Booking cancel(@PathVariable Long id,Authentication a){return service.cancel(id,a.getName(),a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_ADMIN")));}
}
