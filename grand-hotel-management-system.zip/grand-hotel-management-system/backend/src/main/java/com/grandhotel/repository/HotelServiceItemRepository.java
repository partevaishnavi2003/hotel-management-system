package com.grandhotel.repository;
import com.grandhotel.entity.HotelServiceItem; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface HotelServiceItemRepository extends JpaRepository<HotelServiceItem,Long> {
}
