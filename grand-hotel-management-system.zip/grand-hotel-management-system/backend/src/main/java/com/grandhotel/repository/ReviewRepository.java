package com.grandhotel.repository;
import com.grandhotel.entity.Review; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface ReviewRepository extends JpaRepository<Review,Long> {
 List<Review> findByApprovedTrueOrderByCreatedAtDesc();
}
