package com.grandhotel.service;

import com.grandhotel.entity.*;
import com.grandhotel.repository.UserRepository;
import com.grandhotel.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.Map;

@Service
public class AuthService {
 private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
 public AuthService(UserRepository users,PasswordEncoder encoder,JwtService jwt){this.users=users;this.encoder=encoder;this.jwt=jwt;}
 public Map<String,Object> register(String name,String email,String password,String phone){
  if(users.existsByEmail(email.toLowerCase())) throw new ResponseStatusException(HttpStatus.CONFLICT,"Email is already registered");
  User u=new User(); u.setName(name.trim()); u.setEmail(email.trim().toLowerCase()); u.setPassword(encoder.encode(password)); u.setPhone(phone); u.setRole(Role.USER);
  users.save(u); return response(u);
 }
 public Map<String,Object> login(String email,String password){
  User u=users.findByEmail(email.toLowerCase()).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid email or password"));
  if(!u.isActive() || !encoder.matches(password,u.getPassword())) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid email or password");
  return response(u);
 }
 private Map<String,Object> response(User u){return Map.of("token",jwt.generate(u),"user",Map.of("id",u.getId(),"name",u.getName(),"email",u.getEmail(),"role",u.getRole().name(),"phone",u.getPhone()==null?"":u.getPhone()));}
}
