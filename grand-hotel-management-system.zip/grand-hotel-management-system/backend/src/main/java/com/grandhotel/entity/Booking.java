package com.grandhotel.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="bookings", indexes=@Index(columnList="check_in,check_out"))
public class Booking {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false,fetch=FetchType.EAGER) @JoinColumn(nullable=false) private User customer;
 @ManyToOne(optional=false,fetch=FetchType.EAGER) @JoinColumn(nullable=false) private Room room;
 @Column(nullable=false) private LocalDate checkIn;
 @Column(nullable=false) private LocalDate checkOut;
 @Column(nullable=false) private int guests;
 @Column(nullable=false,precision=12,scale=2) private BigDecimal totalPrice;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private BookingStatus status=BookingStatus.CONFIRMED;
 @Column(nullable=false,unique=true) private String bookingReference;
 @Column(nullable=false) private LocalDateTime createdAt=LocalDateTime.now();
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public User getCustomer(){return customer;} public void setCustomer(User v){customer=v;}
 public Room getRoom(){return room;} public void setRoom(Room v){room=v;}
 public LocalDate getCheckIn(){return checkIn;} public void setCheckIn(LocalDate v){checkIn=v;}
 public LocalDate getCheckOut(){return checkOut;} public void setCheckOut(LocalDate v){checkOut=v;}
 public int getGuests(){return guests;} public void setGuests(int v){guests=v;}
 public BigDecimal getTotalPrice(){return totalPrice;} public void setTotalPrice(BigDecimal v){totalPrice=v;}
 public BookingStatus getStatus(){return status;} public void setStatus(BookingStatus v){status=v;}
 public String getBookingReference(){return bookingReference;} public void setBookingReference(String v){bookingReference=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
}
