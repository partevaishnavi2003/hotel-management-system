package com.grandhotel.controller;
import com.grandhotel.entity.*; import com.grandhotel.repository.*; import org.springframework.web.bind.annotation.*; import java.util.List; import java.time.LocalDate;
@RestController public class HotelCatalogController { private final SpecialOfferRepository offers; private final HotelServiceItemRepository services; public HotelCatalogController(SpecialOfferRepository o,HotelServiceItemRepository s){offers=o;services=s;}
 @GetMapping("/api/offers") public List<SpecialOffer> offers(){LocalDate today=LocalDate.now();return offers.findAll().stream().filter(SpecialOffer::isActive).filter(o->o.getStartDate()==null||!o.getStartDate().isAfter(today)).filter(o->o.getEndDate()==null||!o.getEndDate().isBefore(today)).toList();}
 @GetMapping("/api/services") public List<HotelServiceItem> services(){return services.findAll().stream().filter(HotelServiceItem::isActive).toList();}
 @GetMapping("/api/admin/offers") public List<SpecialOffer> allOffers(){return offers.findAll();}
 @PostMapping("/api/admin/offers") public SpecialOffer createOffer(@RequestBody SpecialOffer o){o.setId(null);return offers.save(o);}
 @PutMapping("/api/admin/offers/{id}") public SpecialOffer updateOffer(@PathVariable Long id,@RequestBody SpecialOffer o){o.setId(id);return offers.save(o);}
 @DeleteMapping("/api/admin/offers/{id}") public void deleteOffer(@PathVariable Long id){offers.deleteById(id);}
 @GetMapping("/api/admin/services") public List<HotelServiceItem> allServices(){return services.findAll();}
 @PostMapping("/api/admin/services") public HotelServiceItem createService(@RequestBody HotelServiceItem s){s.setId(null);return services.save(s);}
 @PutMapping("/api/admin/services/{id}") public HotelServiceItem updateService(@PathVariable Long id,@RequestBody HotelServiceItem s){s.setId(id);return services.save(s);}
 @DeleteMapping("/api/admin/services/{id}") public void deleteService(@PathVariable Long id){services.deleteById(id);}
}
