package com.grandhotel.controller;
import com.grandhotel.entity.User; import com.grandhotel.repository.UserRepository; import org.springframework.http.*; import org.springframework.security.core.Authentication; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import jakarta.validation.Valid; import jakarta.validation.constraints.*; import java.util.Map;
@RestController @RequestMapping("/api/profile") public class ProfileController {
 private final UserRepository users; private final PasswordEncoder encoder;
 public ProfileController(UserRepository users,PasswordEncoder encoder){this.users=users;this.encoder=encoder;}
 private User me(Authentication a){return users.findByEmail(a.getName()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"User not found"));}
 @GetMapping public User get(Authentication a){return me(a);}
 public record UpdateProfile(@NotBlank @Size(max=100) String name,@Size(max=30) String phone){}
 @PutMapping public User update(Authentication a,@Valid @RequestBody UpdateProfile r){User u=me(a);u.setName(r.name());u.setPhone(r.phone());return users.save(u);}
 public record ChangePassword(@NotBlank String currentPassword,@Size(min=8,max=100) String newPassword){}
 @PostMapping("/change-password") public Map<String,String> change(Authentication a,@Valid @RequestBody ChangePassword r){User u=me(a);if(r.newPassword()==null||r.newPassword().length()<8)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"New password must contain at least 8 characters");if(!encoder.matches(r.currentPassword(),u.getPassword()))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Current password is incorrect");u.setPassword(encoder.encode(r.newPassword()));users.save(u);return Map.of("message","Password updated. Please sign in again on other devices.");}
}
