package com.grandhotel.repository;
import com.grandhotel.entity.AuditLog; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface AuditLogRepository extends JpaRepository<AuditLog,Long> {
}
