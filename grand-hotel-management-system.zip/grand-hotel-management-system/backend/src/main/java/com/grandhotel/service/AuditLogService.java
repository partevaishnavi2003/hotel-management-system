package com.grandhotel.service;
import com.grandhotel.entity.AuditLog;import com.grandhotel.repository.AuditLogRepository;import org.springframework.stereotype.Service;
@Service public class AuditLogService {private final AuditLogRepository repo;public AuditLogService(AuditLogRepository r){repo=r;}public void record(String actor,String action,String details){AuditLog x=new AuditLog();x.setActorEmail(actor==null?"system":actor);x.setAction(action);x.setDetails(details);repo.save(x);}}
