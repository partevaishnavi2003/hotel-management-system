package com.grandhotel.controller;
import com.grandhotel.entity.*;
import com.grandhotel.repository.*;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;
@RestController @RequestMapping("/api/admin/dashboard")
public class AdminDashboardController {
 private final RoomRepository rooms; private final UserRepository users; private final BookingRepository bookings;
 public AdminDashboardController(RoomRepository rooms,UserRepository users,BookingRepository bookings){this.rooms=rooms;this.users=users;this.bookings=bookings;}
 @GetMapping("/stats") public Map<String,Object> stats(){
  long activeRooms=rooms.findAll().stream().filter(r->r.getStatus()!=RoomStatus.INACTIVE).count();
  long available=rooms.findByStatus(RoomStatus.AVAILABLE).size();
  return Map.of("totalRooms",activeRooms,"availableRooms",available,"totalCustomers",users.findAll().stream().filter(u->u.getRole()==Role.USER).count(),"totalBookings",bookings.count(),"confirmedBookings",bookings.countByStatus(BookingStatus.CONFIRMED),"cancelledBookings",bookings.countByStatus(BookingStatus.CANCELLED),"revenue",bookings.findAll().stream().filter(b->b.getStatus()!=BookingStatus.CANCELLED).map(Booking::getTotalPrice).reduce(BigDecimal.ZERO,BigDecimal::add));
 }
}
