package com.grandhotel.controller;
import com.grandhotel.service.AuthService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final AuthService auth; public AuthController(AuthService auth){this.auth=auth;}
 public record RegisterRequest(@NotBlank @Size(max=100) String name,@Email @NotBlank String email,@Size(min=8,max=100) String password,@Size(max=30) String phone){}
 public record LoginRequest(@Email @NotBlank String email,@NotBlank String password){}
 @PostMapping("/register") public Map<String,Object> register(@Valid @RequestBody RegisterRequest r){return auth.register(r.name(),r.email(),r.password(),r.phone());}
 @PostMapping("/login") public Map<String,Object> login(@Valid @RequestBody LoginRequest r){return auth.login(r.email(),r.password());}
}
