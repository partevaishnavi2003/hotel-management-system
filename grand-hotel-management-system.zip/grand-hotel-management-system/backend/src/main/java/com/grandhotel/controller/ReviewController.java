package com.grandhotel.controller;
import com.grandhotel.entity.*; import com.grandhotel.repository.*; import jakarta.validation.Valid; import jakarta.validation.constraints.*; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import org.springframework.http.HttpStatus; import java.util.List; import java.util.Map; import java.time.LocalDateTime;
@RestController @RequestMapping("/api/reviews") public class ReviewController { private final ReviewRepository reviews; private final UserRepository users; public ReviewController(ReviewRepository r,UserRepository u){reviews=r;users=u;}
 public record PublicReview(Long id,String customerName,int rating,String comment,LocalDateTime createdAt){}
 @GetMapping public List<PublicReview> approved(){return reviews.findByApprovedTrueOrderByCreatedAtDesc().stream().map(v->new PublicReview(v.getId(),v.getCustomer().getName(),v.getRating(),v.getComment(),v.getCreatedAt())).toList();}
 public record ReviewRequest(@Min(1) @Max(5) int rating,@NotBlank @Size(max=2000) String comment){}
 @PostMapping public Review create(Authentication a,@Valid @RequestBody ReviewRequest r){User u=users.findByEmail(a.getName()).orElseThrow();Review v=new Review();v.setCustomer(u);v.setRating(r.rating());v.setComment(r.comment());return reviews.save(v);}
 @GetMapping("/admin") public List<Review> all(){return reviews.findAll();}
 @PatchMapping("/admin/{id}/approval") public Review approval(@PathVariable Long id,@RequestBody Map<String,Boolean> body){Review v=reviews.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Review not found"));v.setApproved(Boolean.TRUE.equals(body.get("approved")));return reviews.save(v);}
}
