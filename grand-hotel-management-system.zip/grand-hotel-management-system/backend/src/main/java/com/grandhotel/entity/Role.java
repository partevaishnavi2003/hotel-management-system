package com.grandhotel.entity;
public enum Role { USER, ADMIN }
