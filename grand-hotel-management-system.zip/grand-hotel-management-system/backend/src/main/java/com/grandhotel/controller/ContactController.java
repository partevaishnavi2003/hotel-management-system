package com.grandhotel.controller;
import com.grandhotel.entity.ContactInquiry; import com.grandhotel.repository.ContactInquiryRepository; import jakarta.validation.Valid; import jakarta.validation.constraints.*; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*; import java.util.List; import java.util.Map;
@RestController @RequestMapping("/api/contact") public class ContactController { private final ContactInquiryRepository repo; public ContactController(ContactInquiryRepository repo){this.repo=repo;}
 public record InquiryRequest(@NotBlank @Size(max=100) String name,@Email @NotBlank String email,@Size(max=30) String phone,@NotBlank @Size(max=3000) String message){}
 @PostMapping public Map<String,Object> create(@Valid @RequestBody InquiryRequest r){ContactInquiry x=new ContactInquiry();x.setName(r.name());x.setEmail(r.email());x.setPhone(r.phone());x.setMessage(r.message());x=repo.save(x);return Map.of("id",x.getId(),"message","Your enquiry has been received. Our team will contact you.");}
 @GetMapping("/admin") public List<ContactInquiry> all(){return repo.findAll();}
 @PatchMapping("/admin/{id}/status") public ContactInquiry status(@PathVariable Long id,@RequestBody Map<String,String> body){ContactInquiry x=repo.findById(id).orElseThrow();x.setStatus(body.getOrDefault("status","IN_PROGRESS"));return repo.save(x);}
}
