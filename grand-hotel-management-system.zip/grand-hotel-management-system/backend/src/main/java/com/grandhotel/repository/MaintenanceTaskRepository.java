package com.grandhotel.repository;
import com.grandhotel.entity.MaintenanceTask; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface MaintenanceTaskRepository extends JpaRepository<MaintenanceTask,Long> {
}
