package com.grandhotel.service;
import com.grandhotel.entity.*;
import com.grandhotel.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
@Service
public class BookingService {
 private final BookingRepository bookings; private final RoomService rooms; private final UserRepository users; private final RoomRepository roomRepository; private final NotificationRepository notifications;
 public BookingService(BookingRepository bookings,RoomService rooms,UserRepository users,RoomRepository roomRepository,NotificationRepository notifications){this.bookings=bookings;this.rooms=rooms;this.users=users;this.roomRepository=roomRepository;this.notifications=notifications;}
 private Room bookingsRoomForUpdate(Long id){return roomRepository.findByIdForUpdate(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Room not found"));}
 @Transactional public Booking create(String email,Long roomId,LocalDate checkIn,LocalDate checkOut,int guests){
  if(checkIn==null||checkOut==null||!checkOut.isAfter(checkIn)||checkIn.isBefore(LocalDate.now())||guests<1) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid dates or guest count");
  Room room=bookingsRoomForUpdate(roomId); if(room.getStatus()!=RoomStatus.AVAILABLE||guests>room.getCapacity())throw new ResponseStatusException(HttpStatus.CONFLICT,"Room is not suitable or available");
  if(bookings.hasOverlap(roomId,checkIn,checkOut,BookingStatus.CANCELLED))throw new ResponseStatusException(HttpStatus.CONFLICT,"Room is no longer available for these dates");
  User user=users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));
  long nights=ChronoUnit.DAYS.between(checkIn,checkOut);
  Booking b=new Booking(); b.setCustomer(user);b.setRoom(room);b.setCheckIn(checkIn);b.setCheckOut(checkOut);b.setGuests(guests);b.setTotalPrice(room.getPricePerNight().multiply(BigDecimal.valueOf(nights)));b.setStatus(BookingStatus.CONFIRMED);b.setBookingReference("GH-"+UUID.randomUUID().toString().substring(0,8).toUpperCase());
  Booking saved=bookings.save(b); Notification n=new Notification();n.setRecipient(user);n.setMessage("Booking confirmed: "+saved.getBookingReference()+". Check-in "+checkIn+".");notifications.save(n);return saved;
 }
 public List<Booking> mine(String email){User u=users.findByEmail(email).orElseThrow();return bookings.findByCustomerIdOrderByCreatedAtDesc(u.getId());}
 public Booking cancel(Long id,String email,boolean admin){Booking b=bookings.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Booking not found"));if(!admin&&!b.getCustomer().getEmail().equals(email))throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Not your booking");if(b.getStatus()==BookingStatus.CHECKED_IN||b.getStatus()==BookingStatus.CHECKED_OUT)throw new ResponseStatusException(HttpStatus.CONFLICT,"This booking can no longer be cancelled");b.setStatus(BookingStatus.CANCELLED);Booking saved=bookings.save(b);Notification n=new Notification();n.setRecipient(b.getCustomer());n.setMessage("Booking cancelled: "+b.getBookingReference()+".");notifications.save(n);return saved;}
 public List<Booking> all(){return bookings.findAllByOrderByCreatedAtDesc();}
 public Booking status(Long id,BookingStatus status){Booking b=bookings.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Booking not found"));b.setStatus(status);return bookings.save(b);}
}
