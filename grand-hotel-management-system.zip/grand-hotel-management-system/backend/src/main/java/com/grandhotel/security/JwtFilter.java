package com.grandhotel.security;

import com.grandhotel.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Component
public class JwtFilter extends OncePerRequestFilter {
 private final JwtService jwtService; private final UserRepository users;
 public JwtFilter(JwtService jwtService,UserRepository users){this.jwtService=jwtService;this.users=users;}
 @Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain) throws ServletException,IOException {
  String header=request.getHeader("Authorization");
  if(header!=null && header.startsWith("Bearer ")) {
   String token=header.substring(7);
   if(jwtService.valid(token)) {
    try { var user=users.findByEmail(jwtService.extractEmail(token)).orElse(null);
     if(user!=null && user.isActive() && SecurityContextHolder.getContext().getAuthentication()==null) {
      var auth=new UsernamePasswordAuthenticationToken(user.getEmail(),null,List.of(new SimpleGrantedAuthority("ROLE_"+user.getRole().name())));
      auth.setDetails(user.getId()); SecurityContextHolder.getContext().setAuthentication(auth);
     }
    } catch(Exception ignored) { SecurityContextHolder.clearContext(); }
   }
  }
  chain.doFilter(request,response);
 }
}
