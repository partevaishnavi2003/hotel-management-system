package com.grandhotel.controller;
import com.grandhotel.entity.*;import com.grandhotel.repository.*;import org.springframework.web.bind.annotation.*;import org.springframework.web.server.ResponseStatusException;import org.springframework.http.HttpStatus;import java.util.*;
@RestController @RequestMapping("/api/admin/maintenance") public class MaintenanceController {private final MaintenanceTaskRepository tasks;private final RoomRepository rooms;public MaintenanceController(MaintenanceTaskRepository t,RoomRepository r){tasks=t;rooms=r;}
 @GetMapping public List<MaintenanceTask> all(){return tasks.findAll();}
 public record TaskRequest(Long roomId,String title,String description,String priority,String status){}
 @PostMapping public MaintenanceTask create(@RequestBody TaskRequest r){if(r.roomId()==null||r.title()==null||r.title().isBlank())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Room and title are required");Room room=rooms.findById(r.roomId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Room not found"));MaintenanceTask t=new MaintenanceTask();t.setRoom(room);t.setTitle(r.title());t.setDescription(r.description());t.setPriority(r.priority()==null?"NORMAL":r.priority());t.setStatus("OPEN");return tasks.save(t);}
 @PatchMapping("/{id}") public MaintenanceTask update(@PathVariable Long id,@RequestBody Map<String,String> body){MaintenanceTask t=tasks.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Task not found"));if(body.containsKey("status"))t.setStatus(body.get("status"));if(body.containsKey("priority"))t.setPriority(body.get("priority"));return tasks.save(t);}
 @DeleteMapping("/{id}") public void delete(@PathVariable Long id){tasks.deleteById(id);}
}
