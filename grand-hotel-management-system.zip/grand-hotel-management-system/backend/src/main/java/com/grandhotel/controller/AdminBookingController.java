package com.grandhotel.controller;
import com.grandhotel.entity.*;
import com.grandhotel.service.BookingService;
import com.grandhotel.service.AuditLogService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/admin/bookings")
public class AdminBookingController {
 private final BookingService service; private final AuditLogService audit; public AdminBookingController(BookingService service,AuditLogService audit){this.service=service;this.audit=audit;}
 @GetMapping public List<Booking> all(){return service.all();}
 public record StatusRequest(BookingStatus status){}
 @PatchMapping("/{id}/status") public Booking status(@PathVariable Long id,@RequestBody StatusRequest r,Authentication a){Booking b=service.status(id,r.status());audit.record(a.getName(),"BOOKING_STATUS_CHANGED",b.getBookingReference()+" -> "+r.status());return b;}
}
