package com.grandhotel.controller;
import com.grandhotel.entity.*;import com.grandhotel.repository.*;import org.springframework.web.bind.annotation.*;import org.springframework.web.server.ResponseStatusException;import org.springframework.http.HttpStatus;import java.util.*;
@RestController @RequestMapping("/api/admin/customers") public class AdminUsersController {private final UserRepository users;public AdminUsersController(UserRepository u){users=u;}
 @GetMapping public List<User> all(){return users.findAll().stream().filter(u->u.getRole()==Role.USER).toList();}
 @PatchMapping("/{id}/active") public User active(@PathVariable Long id,@RequestBody Map<String,Boolean> body){User u=users.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Customer not found"));if(u.getRole()==Role.ADMIN)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Cannot change administrator status here");u.setActive(Boolean.TRUE.equals(body.get("active")));return users.save(u);}
}
