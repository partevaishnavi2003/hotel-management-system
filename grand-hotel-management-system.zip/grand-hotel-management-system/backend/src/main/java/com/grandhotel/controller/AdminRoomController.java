package com.grandhotel.controller;
import com.grandhotel.entity.Room;
import com.grandhotel.service.RoomService;
import com.grandhotel.service.AuditLogService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/admin/rooms")
public class AdminRoomController {
 private final RoomService service; private final AuditLogService audit; public AdminRoomController(RoomService service,AuditLogService audit){this.service=service;this.audit=audit;}
 @GetMapping public List<Room> all(){return service.all();}
 @PostMapping public Room create(@RequestBody Room room,Authentication a){room.setId(null);Room saved=service.save(room);audit.record(a.getName(),"ROOM_CREATED",saved.getRoomNumber());return saved;}
 @PutMapping("/{id}") public Room update(@PathVariable Long id,@RequestBody Room room,Authentication a){Room old=service.get(id);room.setId(id);room.setCreatedAt(old.getCreatedAt());Room saved=service.save(room);audit.record(a.getName(),"ROOM_UPDATED",saved.getRoomNumber());return saved;}
 @DeleteMapping("/{id}") public void delete(@PathVariable Long id,Authentication a){service.delete(id);audit.record(a.getName(),"ROOM_REMOVED",String.valueOf(id));}
}
