package com.grandhotel.entity;
public enum RoomStatus { AVAILABLE, MAINTENANCE, INACTIVE }
