package com.grandhotel.entity;
public enum BookingStatus { CONFIRMED, CANCELLED, CHECKED_IN, CHECKED_OUT }
