package com.grandhotel.controller;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Map;
@RestControllerAdvice
public class ApiExceptionHandler {
 @ExceptionHandler(ResponseStatusException.class) public ResponseEntity<Map<String,String>> status(ResponseStatusException ex){return ResponseEntity.status(ex.getStatusCode()).body(Map.of("error",ex.getReason()==null?"Request failed":ex.getReason()));}
 @ExceptionHandler(MethodArgumentNotValidException.class) public ResponseEntity<Map<String,String>> validation(MethodArgumentNotValidException ex){return ResponseEntity.badRequest().body(Map.of("error","Please check the submitted fields."));}
 @ExceptionHandler(Exception.class) public ResponseEntity<Map<String,String>> general(Exception ex){return ResponseEntity.status(500).body(Map.of("error","Unexpected server error. Check backend logs."));}
}
