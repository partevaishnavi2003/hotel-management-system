package com.grandhotel.repository;
import com.grandhotel.entity.SpecialOffer; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface SpecialOfferRepository extends JpaRepository<SpecialOffer,Long> {
}
