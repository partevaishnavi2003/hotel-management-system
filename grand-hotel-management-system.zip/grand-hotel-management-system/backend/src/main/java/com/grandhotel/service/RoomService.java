package com.grandhotel.service;
import com.grandhotel.entity.*;
import com.grandhotel.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
@Service
public class RoomService {
 private final RoomRepository rooms; private final BookingRepository bookings;
 public RoomService(RoomRepository rooms,BookingRepository bookings){this.rooms=rooms;this.bookings=bookings;}
 public List<Room> all(){return rooms.findAll();}
 public List<Room> available(LocalDate in,LocalDate out,int guests){
  if(in==null||out==null||in.isBefore(LocalDate.now())||!out.isAfter(in)||guests<1) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Provide valid check-in, check-out, and guest count");
  return rooms.findByStatus(RoomStatus.AVAILABLE).stream().filter(r->r.getCapacity()>=guests).filter(r->!bookings.hasOverlap(r.getId(),in,out,BookingStatus.CANCELLED)).toList();
 }
 public Room get(Long id){return rooms.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Room not found"));}
 public Room save(Room r){
  if(r.getRoomNumber()==null||r.getRoomNumber().isBlank()||r.getRoomType()==null||r.getPricePerNight()==null||r.getPricePerNight().compareTo(BigDecimal.ZERO)<=0||r.getCapacity()<1) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Room number, type, positive price, and capacity are required");
  if(r.getStatus()==null)r.setStatus(RoomStatus.AVAILABLE);
  return rooms.save(r);
 }
 public void delete(Long id){Room r=get(id); if(bookings.findAll().stream().anyMatch(b->b.getRoom().getId().equals(id))) {r.setStatus(RoomStatus.INACTIVE);rooms.save(r);} else rooms.delete(r);}
}
