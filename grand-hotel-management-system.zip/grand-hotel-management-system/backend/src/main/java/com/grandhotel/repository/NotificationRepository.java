package com.grandhotel.repository;
import com.grandhotel.entity.Notification; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface NotificationRepository extends JpaRepository<Notification,Long> {
 List<Notification> findByRecipientIdOrderByCreatedAtDesc(Long id);
}
