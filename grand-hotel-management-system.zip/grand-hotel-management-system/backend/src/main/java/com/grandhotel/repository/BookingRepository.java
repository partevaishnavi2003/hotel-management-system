package com.grandhotel.repository;
import com.grandhotel.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;
public interface BookingRepository extends JpaRepository<Booking,Long> {
 List<Booking> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
 @Query("select count(b) > 0 from Booking b where b.room.id=:roomId and b.status <> :cancelled and b.checkIn < :checkOut and b.checkOut > :checkIn")
 boolean hasOverlap(@Param("roomId") Long roomId,@Param("checkIn") LocalDate checkIn,@Param("checkOut") LocalDate checkOut,@Param("cancelled") BookingStatus cancelled);
 long countByStatus(BookingStatus status);
 List<Booking> findAllByOrderByCreatedAtDesc();
}
