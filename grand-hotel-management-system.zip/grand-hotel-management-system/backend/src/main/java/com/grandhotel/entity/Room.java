package com.grandhotel.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="rooms", uniqueConstraints=@UniqueConstraint(columnNames="roomNumber"))
public class Room {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,unique=true) private String roomNumber;
 @Column(nullable=false) private String roomType;
 @Column(nullable=false,precision=12,scale=2) private BigDecimal pricePerNight;
 @Column(nullable=false) private int capacity;
 @Column(length=2000) private String description;
 @Column(length=1000) private String amenities;
 @Column(length=1000) private String imageUrl;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private RoomStatus status=RoomStatus.AVAILABLE;
 @Column(nullable=false) private LocalDateTime createdAt=LocalDateTime.now();
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getRoomNumber(){return roomNumber;} public void setRoomNumber(String v){roomNumber=v;}
 public String getRoomType(){return roomType;} public void setRoomType(String v){roomType=v;}
 public BigDecimal getPricePerNight(){return pricePerNight;} public void setPricePerNight(BigDecimal v){pricePerNight=v;}
 public int getCapacity(){return capacity;} public void setCapacity(int v){capacity=v;}
 public String getDescription(){return description;} public void setDescription(String v){description=v;}
 public String getAmenities(){return amenities;} public void setAmenities(String v){amenities=v;}
 public String getImageUrl(){return imageUrl;} public void setImageUrl(String v){imageUrl=v;}
 public RoomStatus getStatus(){return status;} public void setStatus(RoomStatus v){status=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
}
