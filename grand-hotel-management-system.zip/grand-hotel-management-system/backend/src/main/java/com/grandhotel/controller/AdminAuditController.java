package com.grandhotel.controller;
import com.grandhotel.entity.AuditLog;import com.grandhotel.repository.AuditLogRepository;import org.springframework.web.bind.annotation.*;import java.util.List;
@RestController @RequestMapping("/api/admin/audit-logs") public class AdminAuditController {private final AuditLogRepository repo;public AdminAuditController(AuditLogRepository r){repo=r;}@GetMapping public List<AuditLog> all(){return repo.findAll();}}
