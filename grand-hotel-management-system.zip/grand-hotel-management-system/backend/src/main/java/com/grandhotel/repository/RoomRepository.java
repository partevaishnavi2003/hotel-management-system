package com.grandhotel.repository;
import com.grandhotel.entity.Room;
import com.grandhotel.entity.RoomStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.Optional;
import java.util.List;
public interface RoomRepository extends JpaRepository<Room,Long> { List<Room> findByStatus(RoomStatus status); boolean existsByRoomNumber(String roomNumber); @Lock(LockModeType.PESSIMISTIC_WRITE) @org.springframework.data.jpa.repository.Query("select r from Room r where r.id=:id") Optional<Room> findByIdForUpdate(@Param("id") Long id); }
