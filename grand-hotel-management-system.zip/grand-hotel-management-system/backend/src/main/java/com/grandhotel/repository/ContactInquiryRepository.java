package com.grandhotel.repository;
import com.grandhotel.entity.ContactInquiry; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface ContactInquiryRepository extends JpaRepository<ContactInquiry,Long> {
}
